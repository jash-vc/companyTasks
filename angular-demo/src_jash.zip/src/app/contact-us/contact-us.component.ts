import { Component, OnInit } from '@angular/core';
interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent{
  foods: Food[] = [
    { value: 'standard', viewValue: 'Standard' },
    { value: 'legacy', viewValue: 'Legacy' },
    { value: 'outline', viewValue: 'Outline' }
  ];
}



